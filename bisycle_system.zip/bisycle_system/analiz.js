	$(document).ready(function(){
  $('#btn_select').click(function(){

	var selected1 =$('#select1').val();
	var selected2 =$('#select2').val();
	var selected3 =$('#select3').val();
	var selected4 =$('#select4').val();
	var selected5 =$('#select5').val();
	
	var selected1 =Number(selected1);
	var selected2 =Number(selected2);
	var selected3 =Number(selected3);
	var selected4 =Number(selected4);
	var selected5 =Number(selected5);
	
	var summ = selected1+selected2+selected3+selected4+selected5;

	//var ur = tab.url;
	

	$('#otrk_key').text(summ);
  }
  );
});
