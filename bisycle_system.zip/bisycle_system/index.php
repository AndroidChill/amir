<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Безымянная страница</title>
<style>
   body {
    background-image: url(images/bg.jpg); /* Путь к фоновому изображению */
    background-color: #c7b39b; /* Цвет фона */
   }
  </style>
<meta name="generator" content="WYSIWYG Web Builder 14 - http://www.wysiwygwebbuilder.com">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <link href="bg.css" rel="stylesheet">
    <!--<link href="first.css" rel="stylesheet"> -->
    <!--<link href="index.css" rel="stylesheet">-->
   </head>
   <body>
   <div class="bg">
       <?php include ('navbar.php'); ?>
   </div>
   <!--<input type="submit" id="Button2" onclick="window.location.href='./log_admin.php';return false;" name="" value="Администратор" style="position:absolute;left:50px;top:166px;width:96px;height:25px;z-index:0;">
   <input type="submit" id="Button3" onclick="window.location.href='./log_prep.php';return false;" name="" value="Пользователь" style="position:absolute;left:213px;top:166px;width:96px;height:25px;z-index:1;">
   <input type="submit" id="Button3" onclick="window.location.href='./sign_up.php';return false;" name="" value="Регистрирация" style="position:absolute;left:130px;top:200px;width:100px;height:25px;z-index:1;">
   <div id="wb_Text1" style="position:absolute;left:50px;top:82px;width:250px;height:16px;z-index:2;">
   <span style="color:#000000;font-family:Arial;font-size:13px;">Войти как:</span></div>
   -->
</body>
</html>