<!DOCTYPE html>

<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script src="jquery.min.js"></script>
    <script src="include_shifr.js"></script>
	<script src="include_deshifr.js"></script>
	<script src="select_key.js"></script>
    <title>Шайтанама шифр</title>
	<style>
        table {
            border-collapse: collapse;
            width: 320px;
        }

        td, th {
            border: solid 1px blue;
            padding: 5px;
			font-size: 12px;
        }
		textarea {
			resize: none; /* Запрещаем изменять размер */
		} 
		input.form-control {
    background: -moz-linear-gradient(#00BBD6, #EBFFFF);
    background: -webkit-gradient(linear, 0 0, 0 100%, from(#00BBD6), to(#EBFFFF));
    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#00BBD6', endColorstr='#EBFFFF');
    padding: 3px 7px;
    color: #333;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    border: 1px solid #666;
   }
    </style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
</head>
<body background="bg.jpg">

<div class="container" style="margin: 0px 0px 0px 0px; width: 395px; height: 300px;">
Выбираем ключи.
<table border="1">
<tr>
<td>Введите значения для шифрации сообщения:<br>n=<input id="n_graf" maxlength="10" size="12" value="0">e=<input id="e_graf" maxlength="10" size="12" value="0">d=<input id="d_graf" maxlength="10" size="12" value="0"></td>
</tr>
<tr>
<td>Можете выбрать готовый вариант:
<select id="select">
  <option value="0">Готовые ключи</option>
  <option value="323|5|173">Ключ 1: n=323, e=5, d=173</option>
  <option value="527|7|343">Ключ 2: n=527, e=7, d=343</option>
  <option value="3233|413|17">Ключ 3: n=3233, e=413, d=17</option>
  <option value="123|1|3">Ключ 4: n=, e=, d=</option>
  <option value="123|1|3">Ключ 5: n=, e=, d=</option>
  <option value="123|1|3">Ключ 6: n=, e=, d=</option>
</select></td>
</tr>
<tr>
<td><input id="btn_select" type="submit" value="Выбрать" class="form-control" style="margin: 0px 0px 0px 0px; width: 365px; height: 30px; padding: 5px;"></td>
</tr>
<tr>
<td>Ваш ключ и сертификат на следующие 3 минуты:<div id="otrk_key" style="padding: 10px;"></div></td>
</tr>
</table>
Дешифратор
<table border="1">
<tr>
<td><textarea rows="10" cols="10" id="input_deshifr_message" class="form-control" style="margin: 1px 1px 0px 1px; width: 365px; height: 80px; display:inline;"></textarea></td>
</tr>
<tr>
<td><input id="btn_submit_desifr" type="submit" value="Дешифровать" class="form-control" style="margin: 0px 0px 0px 0px; width: 365px; height: 30px; padding: 5px;"></td>
</tr>
<tr>
<td>Расшифрованное сообщение:<div id="result_deshifr" style="padding: 10px;"></div></td>
</tr>
</table>


Шифратор
<table border="1" style="margin: 0px 0px 2px 0px;">
<tr>
<td>Введите ключ-сертификат:<br>key=<input id="key_shifr" maxlength="30" size="36" value=""></td>
</tr>
<tr>
<td><textarea rows="10" cols="10" id="input_shifr_message" class="form-control" style="margin: 1px 1px 0px 1px; width: 365px; height: 80px; display:inline;"></textarea></td>
</tr>
<tr>
<td><input id="btn_submit_shifr" type="submit" value="Зашифровать" class="form-control" style="margin: 0px 0px 0px 0px; width: 365px; height: 30px; padding: 5px;"></td>
</tr>
<tr>
<td>Зашифрованое сообщение:<div id="result_shifr" style="padding: 10px;"></div></td>
</tr>
</table>
</div>
</body>
</html>
