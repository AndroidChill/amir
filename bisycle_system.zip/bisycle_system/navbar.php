<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="#">КНИТУ-КАИ</a>

    <div class="collapse navbar-collapse justify-content-center" id="navbarTogglerDemo03">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
            <li class="nav-item">
                <input class="btn btn-outline-primary" type="submit" id="Button2" onclick="window.location.href='./log_admin.php';return false;" name="" value="Администратор">
            </li>
            <li class="nav-item">
                <input class="btn btn-outline-primary" type="submit" id="Button3" onclick="window.location.href='./log_prep.php';return false;" name="" value="Пользователь">
            </li>
            <li class="nav-item">
                <input class="btn btn-outline-primary" type="submit" id="Button3" onclick="window.location.href='./sign_up.php';return false;" name="" value="Регистрация">
            </li>
        </ul>
    </div>
</nav>