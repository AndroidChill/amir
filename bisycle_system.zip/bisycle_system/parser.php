<html lang="ru"><head>
        <meta charset="utf-8">
</html>
<?php
header('Content-type: text/html; charset=utf-8');
require_once 'phpQuery.php';

$html = file_get_contents("otz_ht.html");
$doc = phpQuery::newDocument($html);

$hentry = $doc->find('.detal')->text();

$rest = substr($hentry, 4); 
$pieces = explode("ул ", $rest);
for($i=0; $i<33; $i++){
	$pieces[$i]=stristr($pieces[$i], ',', true);
	echo $pieces[$i];
	echo "<br/>";
}
//var_dump($pieces);
//echo $hentry;


?>