<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['form_name']) && $_POST['form_name'] == 'logoutform')
{
   if (session_id() == "")
   {
      session_start();
   }
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
   header('Location: ./index.php');
   exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Безымянная страница</title>
<meta name="generator" content="WYSIWYG Web Builder 14 - http://www.wysiwygwebbuilder.com">
<link href="first.css" rel="stylesheet">
<link href="prof_prep.css" rel="stylesheet">
</head>
<body>
<div id="wb_Text1" style="position:absolute;left:100px;top:83px;width:253px;height:16px;z-index:0;"><span style="color:#000000;font-family:Arial;font-size:13px;">WelLcom to Bisycle System</span></div>
<div id="wb_Logout1" style="position:absolute;left:128px;top:265px;width:94px;height:23px;z-index:1;"><form name="logoutform" method="post" action="<?php echo basename(__FILE__); ?>" id="logoutform">
<input type="hidden" name="form_name" value="logoutform">
<input type="submit" name="logout" value="Logout" id="Logout1">
</form>
</div>
<input type="submit" id="Button1" onclick="window.location.href='./otzov.php';return false;" name="" value="Отзовы" style="position:absolute;left:131px;top:169px;width:96px;height:30px;z-index:2;">
</body>
</html>